import sys
from datetime import datetime
from PySide6.QtGui import QGuiApplication
from PySide6.QtQml import QQmlApplicationEngine
from PySide6.QtCore import QObject, Signal, Property, QTimer, Slot

import database
import audio  # <--- NEW IMPORT

class SmartClockBackend(QObject):
    timeChanged = Signal()
    alarmTriggered = Signal(str)
    alarmsChanged = Signal()

    def __init__(self):
        super().__init__()
        self._current_time = ""
        
        # Initialize DB and Audio
        database.init_db()
        self.audio_manager = audio.AudioManager() # <--- NEW INSTANCE

        # Timer setup
        self._timer = QTimer()
        self._timer.timeout.connect(self._tick)
        self._timer.start(1000)
        self._tick()

    def _tick(self):
        now = datetime.now()
        time_str = now.strftime("%H:%M")
        
        if time_str != self._current_time:
            self._current_time = time_str
            self.timeChanged.emit()
            
            # Only check alarms if the second is 00 (to avoid re-triggering constantly)
            if now.second == 0:
                self._check_alarms(now)

    def _check_alarms(self, now_dt):
        current_time_str = now_dt.strftime("%H:%M")
        current_weekday = str(now_dt.weekday())
        
        active_alarms = database.get_active_alarms()
        
        for alarm in active_alarms:
            if alarm['time'] == current_time_str:
                days = alarm['days']
                if days == "Daily" or current_weekday in days:
                    print(f"ALARM TRIGGERED: {alarm['id']}")
                    
                    # 1. Start Audio
                    self.audio_manager.play_alarm() 
                    
                    # 2. Show UI
                    self.alarmTriggered.emit("Wake Up!")

    # --- Properties ---
    @Property(str, notify=timeChanged)
    def currentTime(self):
        return self._current_time

    @Property(list, notify=alarmsChanged)
    def alarmList(self):
        return database.get_all_alarms()

    # --- Slots (Commands from UI) ---
    
    @Slot()
    def stopAlarm(self):
        """Stops the audio when user dismisses the alarm"""
        print("Stopping Alarm Sound")
        self.audio_manager.stop_alarm()

    @Slot(int)
    def deleteAlarm(self, alarm_id):
        conn = database.get_connection()
        conn.execute("DELETE FROM alarms WHERE id = ?", (alarm_id,))
        conn.commit()
        conn.close()
        self.alarmsChanged.emit()

    @Slot(str, str)
    def createAlarm(self, time_str, days_str):
        database.add_alarm(time_str, days_str)
        self.alarmsChanged.emit()

if __name__ == "__main__":
    app = QGuiApplication(sys.argv)
    engine = QQmlApplicationEngine()
    backend = SmartClockBackend()
    engine.rootContext().setContextProperty("backend", backend)
    engine.load("main.qml")
    if not engine.rootObjects():
        sys.exit(-1)
    sys.exit(app.exec())